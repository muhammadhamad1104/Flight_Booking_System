import bcu.cmp5332.bookingsystem.main.FlightBookingSystemException;
import bcu.cmp5332.bookingsystem.model.Booking;
import bcu.cmp5332.bookingsystem.model.Customer;
import bcu.cmp5332.bookingsystem.model.Flight;

import org.junit.Test;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThrows;
import static org.junit.Assert.assertTrue;

import java.time.LocalDate;
public class FlightBookingSystemTest{
    public Customer customer;
    public Flight flight;
    

    public FlightBookingSystemTest() throws FlightBookingSystemException {
        customer=new Customer(1,"John","1234567890","john@example.com");
        flight=new Flight(1,"AA123","Sydney","Melbourne",LocalDate.parse("2024-11-11"),100,200.0);
    }
    @Test
    public void testAddBookingToCustomer() throws FlightBookingSystemException{
        Booking booking=new Booking(customer,flight,LocalDate.parse("2024-11-11"));
        customer.addBooking(booking);
        assertEquals(1,customer.getBookings().size());
        assertEquals(booking,customer.getBookings().get(0));
    }
    @Test
    public void testAddPassengerToFlight() throws FlightBookingSystemException{
        flight.addPassenger(customer);
        assertEquals(1,flight.getPassengers().size());
        assertTrue(flight.getPassengers().contains(customer));
    }
    @Test
    public void testIssueBooking() throws FlightBookingSystemException{
        Booking booking=new Booking(customer,flight,LocalDate.parse("2024-11-11"));
        flight.addPassenger(customer);
        customer.addBooking(booking);
        assertTrue(flight.getPassengers().contains(customer));
        assertEquals(booking,customer.getBookings().get(0));
        assertEquals(1,customer.getBookings().size());
    }
    @Test
    public void testCancelBooking() throws FlightBookingSystemException{
        Booking booking=new Booking(customer,flight,LocalDate.parse("2024-11-11"));
        customer.addBooking(booking);
        customer.cancelBookingForFlight(flight);
        assertEquals(0,customer.getBookings().size());
        assertFalse(flight.getPassengers().contains(customer));
    }
    @Test
    public void testCustomerDataValidation() throws FlightBookingSystemException{
        Exception exception = assertThrows(FlightBookingSystemException.class,() -> new Customer(1,"","1234567890","invalid-email"));
        assertEquals("Invalid Email Formate",exception.getMessage());
    }
}