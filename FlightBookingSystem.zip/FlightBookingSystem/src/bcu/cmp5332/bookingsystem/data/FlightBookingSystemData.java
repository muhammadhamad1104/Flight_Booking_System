package bcu.cmp5332.bookingsystem.data;



//import bcu.cmp5332.bookingsystem.commands.Command;
import bcu.cmp5332.bookingsystem.main.FlightBookingSystemException;
import bcu.cmp5332.bookingsystem.model.FlightBookingSystem;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class FlightBookingSystemData {
    
    private static final List<DataManager> dataManagers = new ArrayList<>();
    
    // runs only once when the object gets loaded to memory
    static {
        dataManagers.add(new FlightDataManager());
        
        /* Uncomment the two lines below when the implementation of their 
        loadData() and storeData() methods is complete */
        dataManagers.add(new CustomerDataManager());
        dataManagers.add(new BookingDataManager());
    }
    // public static void executeCommand(Command command, FlightBookingSystem fbs) {
    //     try {
    //         command.execute(fbs);
    //         store(fbs);
    //     } catch (IOException e) {
    //         try {
    //             command.rollBack(fbs);
    //             throw new FlightBookingSystemException("failed to save data");
    //         } catch (FlightBookingSystemException Rollback) {
    //             throw new RuntimeException("Rollback failed",Rollback);
    //         }
    //     }catch(FlightBookingSystemException e){
    //         throw new RuntimeException("Command execution failed");
    //     }

    // }
    public static FlightBookingSystem load() throws FlightBookingSystemException, IOException {

        FlightBookingSystem fbs = new FlightBookingSystem();
        for (DataManager dm : dataManagers) {
            dm.loadData(fbs);
        }
        return fbs;
    }

    public static void store(FlightBookingSystem fbs) throws IOException {
        try{
            for (DataManager dm : dataManagers) {
                dm.storeData(fbs);
            }
        }catch(IOException e){
            throw new IOException("Failed to save data",e);
        }
    }
    
}
