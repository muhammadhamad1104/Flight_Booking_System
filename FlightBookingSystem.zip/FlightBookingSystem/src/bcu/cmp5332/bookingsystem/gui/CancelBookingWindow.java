package bcu.cmp5332.bookingsystem.gui;

import bcu.cmp5332.bookingsystem.main.FlightBookingSystemException;
import bcu.cmp5332.bookingsystem.model.Booking;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class CancelBookingWindow extends JFrame implements ActionListener {

    private final MainWindow mw;
    private final JTextField BookingIdText = new JTextField();

    private final JButton cancelBookingBtn = new JButton("Cancel Booking");
    private final JButton cancelBtn = new JButton("Cancel");

    public CancelBookingWindow(MainWindow mw) {
        this.mw = mw;
        initialize();
    }
    private void initialize() {
        setTitle("Cancel Booking");

        setSize(300, 220);
        JPanel topPanel = new JPanel(new GridLayout(2,2));
        topPanel.add(new JLabel("Booking ID : "));
        topPanel.add(BookingIdText);

        JPanel bottomPanel = new JPanel(new GridLayout(1,2));
        bottomPanel.add(cancelBookingBtn);
        bottomPanel.add(cancelBtn);

        cancelBookingBtn.addActionListener(this);
        cancelBtn.addActionListener(this);

        this.getContentPane().add(topPanel, BorderLayout.CENTER);
        this.getContentPane().add(bottomPanel, BorderLayout.SOUTH);

        setLocationRelativeTo(mw);
        setVisible(true);
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == cancelBookingBtn) {
            cancelBook();
        } else if (e.getSource() == cancelBtn) {
            this.setVisible(false);
        }
    }
    private void cancelBook() {
        try{
            int bookingId = Integer.parseInt(BookingIdText.getText().trim());

            Booking booking = mw.getFlightBookingSystem().getBookingByID(bookingId);
            
            mw.getFlightBookingSystem().cancelBooking(booking.getCustomer(), booking.getFlight());

            JOptionPane.showMessageDialog(this, "Booking cancelled successfully", "Success", JOptionPane.INFORMATION_MESSAGE);
            this.setVisible(false);
            this.dispose();
        }catch(NumberFormatException ex){
            JOptionPane.showMessageDialog(this, "Please enter a valid number", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (FlightBookingSystemException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }


}