package bcu.cmp5332.bookingsystem.gui;

import bcu.cmp5332.bookingsystem.model.Flight;
import java.awt.BorderLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
//import javax.swing.JTextField;

public class FlightPassengerWindow extends JFrame{// implements ActionListener {

    private final Flight flight;
    private final JTextArea passengersText = new JTextArea();
    private final JButton closeBtn = new JButton("Close");
    public FlightPassengerWindow(Flight flight) {
        this.flight=flight;
        initialize();
    }

    /**
     * Initialize the contents of the frame.
     */
    private void initialize() {

        setTitle("Passenger for Flight " + flight.getFlightNumber());

        setSize(350, 220);
        JPanel mainPanel = new JPanel(new BorderLayout());
        passengersText.setEditable(false);
        passengersText.setText(getPassengerText());
        mainPanel.add(new JScrollPane(passengersText), BorderLayout.CENTER);
        closeBtn.addActionListener(e->this.dispose());
        mainPanel.add(closeBtn, BorderLayout.SOUTH);
        this.getContentPane().add(mainPanel);
        setLocationRelativeTo(null);
        setVisible(true);
        
    }
    private String getPassengerText() {
        StringBuilder sb = new StringBuilder();
        flight.getPassengers().forEach(p -> sb.append(passengersText.getName()).append("\n"));
        return sb.toString();
    }
}