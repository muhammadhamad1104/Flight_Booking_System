package bcu.cmp5332.bookingsystem.gui;

import bcu.cmp5332.bookingsystem.main.FlightBookingSystemException;
import bcu.cmp5332.bookingsystem.model.Customer;
import bcu.cmp5332.bookingsystem.model.Flight;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class IssueBookingWindow extends JFrame implements ActionListener {

    private final MainWindow mw;
    private final JTextField CustomerIdText = new JTextField();
    private final JTextField flightIdText = new JTextField();

    private final JButton issueBtn = new JButton("Issue");
    private final JButton cancelBtn = new JButton("Cancel");

    public IssueBookingWindow(MainWindow mw) {
        this.mw = mw;
        initialize();
    }
    private void initialize() {
        setTitle("Issue Booking");

        setSize(300, 220);
        JPanel topPanel = new JPanel(new GridLayout(3,2));
        topPanel.add(new JLabel("Customer ID : "));
        topPanel.add(CustomerIdText);
        topPanel.add(new JLabel("Flight ID : "));
        topPanel.add(flightIdText);

        JPanel bottomPanel = new JPanel(new GridLayout(1,2));
        bottomPanel.add(issueBtn);
        bottomPanel.add(cancelBtn);

        issueBtn.addActionListener(this);
        cancelBtn.addActionListener(this);

        this.getContentPane().add(topPanel, BorderLayout.CENTER);
        this.getContentPane().add(bottomPanel, BorderLayout.SOUTH);

        setLocationRelativeTo(mw);
        setVisible(true);
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == issueBtn) {
            addBook();
        } else if (e.getSource() == cancelBtn) {
            this.setVisible(false);
        }
    }
    private void addBook() {
        try{
            int customerId = Integer.parseInt(CustomerIdText.getText().trim());
            int flightId = Integer.parseInt(flightIdText.getText().trim());
            Customer customer = mw.getFlightBookingSystem().getCustomerByID(customerId);
            Flight flight = mw.getFlightBookingSystem().getFlightByID(flightId);
            double dynamicPrice = mw.getFlightBookingSystem().calculateFlightPrice(flight);
            mw.getFlightBookingSystem().issueBooking(customer, flight, dynamicPrice);
            JOptionPane.showMessageDialog(this, "Booking issued for Customer #"+customerId+" on flight #"+flightId);
            this.setVisible(false);
            this.dispose();
        }catch(NumberFormatException ex){
            JOptionPane.showMessageDialog(this, "Please enter a valid number", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (FlightBookingSystemException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }


}