package bcu.cmp5332.bookingsystem.gui;

import bcu.cmp5332.bookingsystem.commands.AddCustomer;
import bcu.cmp5332.bookingsystem.commands.Command;
import bcu.cmp5332.bookingsystem.main.FlightBookingSystemException;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class AddCustomerWindow extends JFrame implements ActionListener {
    private final MainWindow mw;
    private final JTextField NameText = new JTextField();
    private final JTextField PhoneText = new JTextField();
    private final JTextField EmailText = new JTextField();

    private final JButton addBtn = new JButton("Add");
    private final JButton cancelBtn = new JButton("Cancel");

    public AddCustomerWindow(MainWindow mw) {
        this.mw = mw;
        initialize();
    }
    private void initialize() {
        setTitle("Add a New Customer");

        setSize(300, 220);
        JPanel topPanel = new JPanel(new GridLayout(3,2));
        topPanel.add(new JLabel("Name : "));
        topPanel.add(NameText);
        topPanel.add(new JLabel("Phone : "));
        topPanel.add(PhoneText);
        topPanel.add(new JLabel("Email : "));
        topPanel.add(EmailText);

        JPanel bottomPanel = new JPanel(new GridLayout(1,2));
        bottomPanel.add(addBtn);
        bottomPanel.add(cancelBtn);

        addBtn.addActionListener(this);
        cancelBtn.addActionListener(this);

        this.getContentPane().add(topPanel, BorderLayout.CENTER);
        this.getContentPane().add(bottomPanel, BorderLayout.SOUTH);

        setLocationRelativeTo(mw);
        setVisible(true);
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == addBtn) {
            addBook();
        } else if (e.getSource() == cancelBtn) {
            this.setVisible(false);
        }
    }
    private void addBook() {
        try{
            String name = NameText.getText().trim();
            String phone = PhoneText.getText().trim();
            String email = EmailText.getText().trim();
            if(name.isEmpty() || phone.isEmpty() || email.isEmpty()){
                throw new FlightBookingSystemException("Please fill all the fields");
            }
            Command addCustomer = new AddCustomer(name, phone, email);
            addCustomer.execute(mw.getFlightBookingSystem());
            mw.displayCustomers();
            this.setVisible(false);
            this.dispose();
        } catch (FlightBookingSystemException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }


}
