package bcu.cmp5332.bookingsystem.gui;

//import bcu.cmp5332.bookingsystem.commands.CancelBooking;
import bcu.cmp5332.bookingsystem.data.FlightBookingSystemData;
import bcu.cmp5332.bookingsystem.main.FlightBookingSystemException;
import bcu.cmp5332.bookingsystem.model.Customer;
import bcu.cmp5332.bookingsystem.model.Flight;
import bcu.cmp5332.bookingsystem.model.FlightBookingSystem;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.List;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.UIManager;
//import javax.xml.crypto.dsig.spec.ExcC14NParameterSpec;

public class MainWindow extends JFrame implements ActionListener {

    private JMenuBar menuBar;
    private JMenu adminMenu;
    private JMenu flightsMenu;
    private JMenu bookingsMenu;
    private JMenu customersMenu;

    private JMenuItem adminExit;

    private JMenuItem flightsView;
    private JMenuItem flightsAdd;
    private JMenuItem flightsDel;
    private JMenuItem flightViewPassengrs;
    
    private JMenuItem bookingsIssue;
    private JMenuItem bookingsUpdate;
    private JMenuItem bookingsCancel;

    private JMenuItem custView;
    private JMenuItem custAdd;
    private JMenuItem custDel;
    private JMenuItem custViewDetails;

    private final FlightBookingSystem fbs;

    public MainWindow(FlightBookingSystem fbs) {

        initialize();
        this.fbs = fbs;
    }
    
    public FlightBookingSystem getFlightBookingSystem() {
        return fbs;
    }

    /**
     * Initialize the contents of the frame.
     */
    private void initialize() {

        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch(ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            //ex.printStackTrace();
        }

        setTitle("Flight Booking Management System");

        menuBar = new JMenuBar();
        setJMenuBar(menuBar);

        //adding adminMenu menu and menu items
        adminMenu = new JMenu("Admin");
        menuBar.add(adminMenu);

        adminExit = new JMenuItem("Exit");
        adminMenu.add(adminExit);
        adminExit.addActionListener(this);

        // adding Flights menu and menu items
        flightsMenu = new JMenu("Flights");
        menuBar.add(flightsMenu);

        flightsView = new JMenuItem("View");
        flightsAdd = new JMenuItem("Add");
        flightsDel = new JMenuItem("Delete");
        flightViewPassengrs=new JMenuItem("View Passengers");
        flightsMenu.add(flightsView);
        flightsMenu.add(flightsAdd);
        flightsMenu.add(flightsDel);
        flightsMenu.add(flightViewPassengrs);
        // adding action listener for Flights menu items
        for (int i = 0; i < flightsMenu.getItemCount(); i++) {
            flightsMenu.getItem(i).addActionListener(this);
        }
        
        // adding Bookings menu and menu items
        bookingsMenu = new JMenu("Bookings");
        menuBar.add(bookingsMenu);
        bookingsIssue = new JMenuItem("Issue");
        bookingsUpdate = new JMenuItem("Update");
        bookingsCancel = new JMenuItem("Cancel");
        bookingsMenu.add(bookingsIssue);
        bookingsMenu.add(bookingsUpdate);
        bookingsMenu.add(bookingsCancel);
        // adding action listener for Bookings menu items
        for (int i = 0; i < bookingsMenu.getItemCount(); i++) {
            bookingsMenu.getItem(i).addActionListener(this);
        }

        // adding Customers menu and menu items
        customersMenu = new JMenu("Customers");
        menuBar.add(customersMenu);

        custView = new JMenuItem("View");
        custAdd = new JMenuItem("Add");
        custDel = new JMenuItem("Delete");
        custViewDetails = new JMenuItem("View Details");

        customersMenu.add(custView);
        customersMenu.add(custAdd);
        customersMenu.add(custDel);
        customersMenu.add(custViewDetails);
        for (int i = 0; i < customersMenu.getItemCount(); i++) {
            customersMenu.getItem(i).addActionListener(this);
        }

        setSize(800, 500);

        setVisible(true);
        setAutoRequestFocus(true);
        toFront();
        setDefaultCloseOperation(EXIT_ON_CLOSE);
/* Uncomment the following line to not terminate the console app when the window is closed */
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);        
        setVisible(true);
    }	

/* Uncomment the following code to run the GUI version directly from the IDE */
    public static void main(String[] args) throws IOException, FlightBookingSystemException {
        FlightBookingSystem fbs;
        fbs = FlightBookingSystemData.load();
        MainWindow mainWindow=new MainWindow(fbs);	
        mainWindow.setVisible(true);	
    }



    @Override
    public void actionPerformed(ActionEvent ae) {

        if (ae.getSource() == adminExit) {
            try {
                FlightBookingSystemData.store(fbs);
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
            System.exit(0);
        } else if (ae.getSource() == flightsView) {
            displayFlights();
            
        } else if (ae.getSource() == flightsAdd) {
            AddFlightWindow addFlightWindow=new AddFlightWindow(this);
            addFlightWindow.setVisible(true);
        } else if (ae.getSource() == flightsDel) {
            String flightIdStr=JOptionPane.showInputDialog(this, "Enter Flight ID: ");
            try {
                int flightId=Integer.parseInt(flightIdStr);
                Flight flight=fbs.getFlightByID(flightId);
                fbs.removeFlight(flight);
                JOptionPane.showMessageDialog(this, "Flight removed successfully", "Success", JOptionPane.INFORMATION_MESSAGE);
                displayFlights();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Invalid Flight ID", "Error", JOptionPane.ERROR_MESSAGE);
            } catch (FlightBookingSystemException ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }else if (ae.getSource()==flightViewPassengrs) {
            String flightIdStr=JOptionPane.showInputDialog(this, "Enter Flight ID: ");
            try {
                int flightId=Integer.parseInt(flightIdStr);
                Flight flight=fbs.getFlightByID(flightId);
                // FlightPassengerWindow flightPassengerWindow= new FlightPassengerWindow(flight);
                // flightPassengerWindow.setVisible(true);
                displayflightViewPassengrs(flight);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Invalid Flight ID", "Error", JOptionPane.ERROR_MESSAGE);
            } catch (FlightBookingSystemException ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else if (ae.getSource() == bookingsIssue) {
            IssueBookingWindow issueBookingWindow=new IssueBookingWindow(this);
            issueBookingWindow.setVisible(true);            
        } else if (ae.getSource() == bookingsCancel) {
            CancelBookingWindow cancelBookingWindow=new CancelBookingWindow(this);
            cancelBookingWindow.setVisible(true);            
        } else if (ae.getSource() == bookingsUpdate) {
            UpdateBookingWindow updateBookingWindow=new UpdateBookingWindow(this);
            updateBookingWindow.setVisible(true);
        } else if (ae.getSource() == custView) {
            displayCustomers();
            
        } else if (ae.getSource() == custAdd) {
            AddCustomerWindow addCustomerWindow=new AddCustomerWindow(this);
            addCustomerWindow.setVisible(true);
        } else if (ae.getSource() == custDel) {
            String customerIdStr=JOptionPane.showInputDialog(this, "Enter Customer ID: ");
            try {
                int customerId=Integer.parseInt(customerIdStr);
                Customer customer=fbs.getCustomerByID(customerId);
                fbs.removeCustomer(customer);
                JOptionPane.showMessageDialog(this, "Customer removed successfully", "Success", JOptionPane.INFORMATION_MESSAGE);
                displayCustomers();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Invalid Customer ID", "Error", JOptionPane.ERROR_MESSAGE);
            } catch (FlightBookingSystemException ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else if (ae.getSource() == custViewDetails) {
            String custIdStr=JOptionPane.showInputDialog(this, "Enter Customer ID: ");
            try {
                int customerId=Integer.parseInt(custIdStr);
                Customer customer=fbs.getCustomerByID(customerId);
                if(customer!=null){
                    displayCustomersDetails(customer);
                }else{
                    JOptionPane.showMessageDialog(this, "Customer not found", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Invalid Customer ID", "Error", JOptionPane.ERROR_MESSAGE);
            }catch (FlightBookingSystemException ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
            
        }
    }

    public void displayFlights() {
        List<Flight> flightsList = fbs.getFlights();
        // headers for the table
        String[] columns = new String[]{"Flight No", "Origin", "Destination", "Departure Date","Capacity","Price"};

        Object[][] data = new Object[flightsList.size()][6];
        for (int i = 0; i < flightsList.size(); i++) {
            Flight flight = flightsList.get(i);
            data[i][0] = flight.getFlightNumber();
            data[i][1] = flight.getOrigin();
            data[i][2] = flight.getDestination();
            data[i][3] = flight.getDepartureDate();
            data[i][4] = flight.getCapacity();
            data[i][5] = flight.getPrice();
        }

        JTable table = new JTable(data, columns);
        this.getContentPane().removeAll();
        this.getContentPane().add(new JScrollPane(table));
        this.revalidate();
    }	
    public void displayCustomers() {
        List<Customer> customerList = fbs.getCustomers();
        // headers for the table
        String[] columns = new String[]{"Customer ID", "Name", "Phone", "Email"};

        Object[][] data = new Object[customerList.size()][4];
        for (int i = 0; i < customerList.size(); i++) {
            Customer customer = customerList.get(i);
            data[i][0] = customer.getID();
            data[i][1] = customer.getName();
            data[i][2] = customer.getPhone();
            data[i][3] = customer.getEmail();
        }

        JTable table = new JTable(data, columns);
        this.getContentPane().removeAll();
        this.getContentPane().add(new JScrollPane(table));
        this.revalidate();
    }	
    public void displayCustomersDetails(Customer customer) {
        // headers for the table
        String[] columns = new String[]{"Customer ID", "Name", "Phone", "Email"};
        Object[][] data = new Object[1][4];
        data[0][0] = customer.getID();
        data[0][1] = customer.getName();
        data[0][2] = customer.getPhone();
        data[0][3] = customer.getEmail();

        JTable table = new JTable(data, columns);
        this.getContentPane().removeAll();
        this.getContentPane().add(new JScrollPane(table));
        this.revalidate();
    }
    public void displayflightViewPassengrs(Flight flight) {
        // headers for the table
        String[] columns = new String[]{"Customer ID", "Name", "Phone", "Email"};
        Object[][] data = new Object[flight.getPassengers().size()][4];
        for (int i = 0; i < flight.getPassengers().size(); i++) {
            Customer customer = flight.getPassengers().get(i);
            data[i][0] = customer.getID();
            data[i][1] = customer.getName();
            data[i][2] = customer.getPhone();
            data[i][3] = customer.getEmail();
        }

        JTable table = new JTable(data, columns);
        this.getContentPane().removeAll();
        this.getContentPane().add(new JScrollPane(table));
        this.revalidate();
    }
}
