package bcu.cmp5332.bookingsystem.gui;

import bcu.cmp5332.bookingsystem.main.FlightBookingSystemException;
import bcu.cmp5332.bookingsystem.model.Booking;
import bcu.cmp5332.bookingsystem.model.Customer;
import bcu.cmp5332.bookingsystem.model.Flight;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class UpdateBookingWindow extends JFrame implements ActionListener {

    private final MainWindow mw;
    private final JTextField BookingIdText = new JTextField();
    private final JTextField flightIdText = new JTextField();
    private final JTextField newflightIdText = new JTextField();

    private final JButton updateBtn = new JButton("Update");
    private final JButton cancelBtn = new JButton("Cancel");

    public UpdateBookingWindow(MainWindow mw) {
        this.mw = mw;
        initialize();
    }
    private void initialize() {
        setTitle("Update Booking");

        setSize(300, 220);
        JPanel topPanel = new JPanel(new GridLayout(4,2));
        topPanel.add(new JLabel("Booking ID : "));
        topPanel.add(BookingIdText);
        topPanel.add(new JLabel("Current Flight ID : "));
        topPanel.add(flightIdText);
        topPanel.add(new JLabel("New Flight ID : "));
        topPanel.add(newflightIdText);

        JPanel bottomPanel = new JPanel(new GridLayout(1,2));
        bottomPanel.add(updateBtn);
        bottomPanel.add(cancelBtn);

        updateBtn.addActionListener(this);
        cancelBtn.addActionListener(this);

        this.getContentPane().add(topPanel, BorderLayout.CENTER);
        this.getContentPane().add(bottomPanel, BorderLayout.SOUTH);

        setLocationRelativeTo(mw);
        setVisible(true);
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == updateBtn) {
            addBook();
        } else if (e.getSource() == cancelBtn) {
            this.setVisible(false);
        }
    }
    private void addBook() {
        try{
            int bookingId = Integer.parseInt(BookingIdText.getText().trim());
            int flightId = Integer.parseInt(flightIdText.getText().trim());
            int newflightId = Integer.parseInt(newflightIdText.getText().trim());

            Booking booking = mw.getFlightBookingSystem().getBookingByID(bookingId);
            Customer customer = booking.getCustomer();
            Flight currentflight = mw.getFlightBookingSystem().getFlightByID(flightId);
            Flight newflight = mw.getFlightBookingSystem().getFlightByID(newflightId);
            mw.getFlightBookingSystem().updateBooking(booking, currentflight, newflight);

            JOptionPane.showMessageDialog(this, "Booking updated successfully", "Success", JOptionPane.INFORMATION_MESSAGE);
            this.setVisible(false);
            this.dispose();
        }catch(NumberFormatException ex){
            JOptionPane.showMessageDialog(this, "Please enter a valid number", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (FlightBookingSystemException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }


}