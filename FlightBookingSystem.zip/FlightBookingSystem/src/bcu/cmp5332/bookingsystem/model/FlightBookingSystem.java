package bcu.cmp5332.bookingsystem.model;

import bcu.cmp5332.bookingsystem.main.FlightBookingSystemException;
import java.time.LocalDate;
import java.util.*;

public class FlightBookingSystem {
    
    private final LocalDate systemDate = LocalDate.parse("2024-11-11");
    
    private final Map<Integer, Customer> customers = new TreeMap<>();
    private final Map<Integer, Flight> flights = new TreeMap<>();
    private final double cancellationFee = 50.0;
    public LocalDate getSystemDate() {
        return systemDate;
    }
    public boolean hasPassenger(Customer customer){
        return customers.containsValue(customer);
    }
    /*
     * Returns a list of all bookings in the system that are not departed.
     */
    public List<Flight> getFutureFlights(){
        List<Flight> out = new ArrayList<>();
        for(Flight flight:flights.values()){
            if(!flight.isDeleted() && flight.getDepartureDate().isAfter(systemDate)){
                out.add(flight);
            }
        }
        return Collections.unmodifiableList(out);
    }
    /*
     * Returns a list of all flights in the system that are not deleted.
     * @return List of active flights
     */
    public List<Flight> getFlights() {
        List<Flight> out = new ArrayList<>();
        for(Flight flight:flights.values()){
            if(!flight.isDeleted()){
                out.add(flight);
            }
        }
        return Collections.unmodifiableList(out);
    }
    /*
     * calculate the price of a flight based on the number of days left to the departure date, the capacity factor and the base price
     */
    public double calculateFlightPrice(Flight flight){
        double daysLeft = java.time.temporal.ChronoUnit.DAYS.between(systemDate, flight.getDepartureDate());
        double capacityFactor=1.0+(flight.getCapacity()-flight.getPassengers().size())/(double)flight.getCapacity();
        return flight.getPrice()*capacityFactor*(1.0+0.1*daysLeft);
    }
    // public List<Flight> getBookingsForCustomer(Customer customer){
    //     List<Flight> bookings=new ArrayList<>();
    //     for(Booking booking:bookingsList){
    //         if(booking.getCustomer().equals(customer)){
    //             bookings.add(booking.getFlight());
    //         }
    //     }
    //     return bookings;
    // }
    /*
     * cancel booking and apply cancel fee
     */
    public void cancelBooking(Customer customer,Flight flight) throws FlightBookingSystemException {
        if(!flight.getPassengers().contains(customer)){
            throw new FlightBookingSystemException("Cannot cancel booking for a flight that has already departed.");
        }
        customer.cancelBookingForFlight(flight);
        flight.removePassenger(customer);
        System.out.println("Booking cancelled for customer #"+customer.getID()+" on flight #"+flight.getId());
        System.out.println("Cancellation fee of $"+cancellationFee+" applied.");
    }
    /*
     * issue a booking for a customer on a flight
     */
    public void issueBooking(Customer customer,Flight flight,double bookingPrice) throws FlightBookingSystemException {
        if(flight.getPassengers().size()>=flight.getCapacity()){
            throw new FlightBookingSystemException("The flight is full");
        }
        if(bookingPrice<=0){
            throw new FlightBookingSystemException("Booking Price must be greater than zero.");
        }
        Booking booking=new Booking(customer,flight,systemDate);
        customer.addBooking(booking);
        flight.addPassenger(customer);
        System.out.println("Booking added for customer #"+customer.getID()+" on flight #"+flight.getId());
    }
    /*
     * retrive a flight by its ID if it is not marked as deleted
     * @param id the ID of the flight
     * @return the flight with the given ID
     * @throws FlightBookingSystemException if there is no flight with the given ID
     */
    public Flight getFlightByID(int id) throws FlightBookingSystemException {
        if (!flights.containsKey(id)||flights.get(id).isDeleted()) {
            throw new FlightBookingSystemException("There is no flight with that ID.");
        }
        return flights.get(id);
    }
    /*
     * Add a flight to the system if there is no flight with the same number and departure date
     * @param flight the flight to be added
     *  @throws FlightBookingSystemException if there is a flight with the same number and departure date in the system
     */
    public void addFlight(Flight flight) throws FlightBookingSystemException {
        if (flights.containsKey(flight.getId())) {
            throw new IllegalArgumentException("Duplicate flight ID.");
        }
        for (Flight existing : flights.values()) {
            if (!existing.isDeleted()&&existing.getFlightNumber().equals(flight.getFlightNumber()) 
                && existing.getDepartureDate().isEqual(flight.getDepartureDate())) {
                throw new FlightBookingSystemException("There is a flight with same "
                        + "number and departure date in the system");
            }
        }
        flights.put(flight.getId(), flight);
    }
    /*
     * mark a flight as deleted
     * @param removedFlight the flight to be removed
     */
    public void removeFlight(Flight removedFlight) {
        removedFlight.setDeleted(true);
    }
    /*
     * Returns a list of all customers in the system that are not deleted.
     * @return List of active customers
     */
    public List<Customer> getCustomers() {
        List<Customer> out = new ArrayList<>();
        for(Customer customer:customers.values()){
            if(!customer.isDeleted()){
                out.add(customer);
            }
        }
        return Collections.unmodifiableList(out);
    }
    /*
     * retrive a customer by its ID if it is not marked as deleted
     * @param id the ID of the customer
     * @return the customer with the given ID
     * @throws FlightBookingSystemException if there is no customer with the given ID
     */
    public Customer getCustomerByID(int id) throws FlightBookingSystemException {
        if (!customers.containsKey(id)||customers.get(id).isDeleted()) {
            throw new FlightBookingSystemException("There is no customer with that ID.");
        }
        return customers.get(id);
    }
    /*
     * Add a customer to the system if there is no customer with the same email
     * @param customer the customer to be added
     * @throws FlightBookingSystemException if there is a customer with the same email in the system
     */
    public void addCustomer(Customer customer)throws FlightBookingSystemException {
        // implementation here
        if (customers.containsKey(customer.getID())) {
            throw new IllegalArgumentException("Duplicate customer ID.");
        }
        for (Customer existing : customers.values()) {
            if (!existing.isDeleted()&&existing.getEmail().equals(customer.getEmail())){
                throw new FlightBookingSystemException("A Customer with same email already exsists");
            }
        }
        customers.put(customer.getID(), customer);
    }
    /*
     * mark a customer as deleted
     * @param removedCustomer the customer to be removed
     */
    public void removeCustomer(Customer removedCustomer) {
        removedCustomer.setDeleted(true);
    }

    public Booking getBookingByID(int bookingId)throws FlightBookingSystemException {
        for(Customer customer:customers.values()){
            for(Booking booking:customer.getBookings()){
                if(booking.getId()==bookingId){
                    return booking;
                }
            }
        }
        throw new FlightBookingSystemException("There is no booking with that ID.");
    }
    public void updateBooking(Booking booking, Flight currentflight, Flight newflight) throws FlightBookingSystemException {
        if(newflight.getPassengers().size()>=newflight.getCapacity()){
            throw new FlightBookingSystemException("The flight is full");
        }
                // implementation here
        booking.setFlight(newflight);
        currentflight.removePassenger(booking.getCustomer());
        newflight.addPassenger(booking.getCustomer());
        System.out.println("Booking updated for customer #"+booking.getCustomer().getID()+" to flight #"+newflight.getId());
        
    }
}
