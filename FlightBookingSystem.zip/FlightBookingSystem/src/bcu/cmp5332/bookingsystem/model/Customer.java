package bcu.cmp5332.bookingsystem.model;

import bcu.cmp5332.bookingsystem.main.FlightBookingSystemException;
import java.util.ArrayList;
import java.util.List;

public class Customer {
    
    private int id;
    private String name;
    private String phone;
    private String email;
    private final List<Booking> bookings;
    private boolean isDeleted;
    // implementation of constructor
    public Customer(int id,String name,String phone,String Email)throws FlightBookingSystemException{
        this.id=id;
        this.name=name;
        this.phone=phone;
        if(Email==null||Email.isEmpty()){
           throw new FlightBookingSystemException("Email cannot be empty");
        }
        if(!Email.matches("[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]+{2,6}")){
           throw new FlightBookingSystemException("Invalid Email Formate");
        }
        this.email=Email;
        this.bookings = new ArrayList<>();
        this.isDeleted = false;
    }
    public boolean isDeleted() {
        return isDeleted;
    }
    public void setDeleted(boolean isDeleted) {
        this.isDeleted = isDeleted;
    }
    
    // implementation of Getter and Setter methods
    public void setID(int id){
        this.id=id;
    }
    public void setName(String name){
        this.name=name;
    }
    public void setPhone(String phone){
        this.phone=phone;
    }
    public void setEmail(String email)throws FlightBookingSystemException{
        if(email==null||email.isEmpty()){
            throw new FlightBookingSystemException("Email cannot be empty");
        }
        if(!email.matches("[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]+{2,6}")){
            throw new FlightBookingSystemException("Invalid Email Formate");
        }
        this.email=email;
    }
    public int getID(){
        return this.id;
    }
    public String getName(){
        return this.name;
    }
    public String getPhone(){
        return this.phone;
    }
    public String getEmail(){
        return this.email;
    }
    public List<Booking> getBookings(){
        return new ArrayList<>(bookings);
    }
    public String getDetailsShort() {
        return "Customer #" + id + ", Name : " + name + ", Phone : " + phone+", Email : "+email;
    }

    public String getDetailsLong() {
        String details="Customer #" + id + "\nName : " + name + "\nPhone : " + phone +"\nEmail : "+email+"\n------------------\n";
        details+="Bookings :\n";
        if(bookings.isEmpty()){
            details+=" No booking\n";
        }else{
            for(Booking booking : bookings){
                details+="* Booking Date : "+booking.getBookingDate()+" for "+booking.getFlight()+"\n";
            }
            details+=bookings.size()+" booking(s)";
        }
        return details;
    }
    public void addBooking(Booking booking)throws FlightBookingSystemException {
        // implementation here
        if(bookings.contains(booking)){
            throw new FlightBookingSystemException("Booking already exsist");
        }
        bookings.add(booking);
    }
    public void cancelBookingForFlight(Flight flight)throws FlightBookingSystemException {
        // implementation here
        boolean bookingFound=false;
        for(Booking booking : bookings){
            if(booking.getFlight().equals(flight)){
                bookings.remove(booking);
                bookingFound=true;
                break;
            }
        }
        if(!bookingFound){
            throw new FlightBookingSystemException("Booking does not exsist");
        }
    }

    public Booking getBookingByFlight(Flight flight) {
        return bookings.stream()
                .filter(booking -> booking.getFlight().equals(flight))
                .findFirst()
                .orElse(null);
    }
    public boolean equals(Object obj){
        if(this==obj){
            return true;
        }
        if(obj==null||getClass()!=obj.getClass()){
            return false;
        }
        Customer other=(Customer)obj;
        return this.id==other.id;
    }
    public int hashCode(){
        return id;
    }
}
