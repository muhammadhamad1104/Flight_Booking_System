package bcu.cmp5332.bookingsystem.model;

import java.time.LocalDate;

public class Booking {
    private final int id;
    private Customer customer;
    private Flight flight;
    private LocalDate bookingDate;
    private static int counter=1;

    public Booking(Customer customer, Flight flight, LocalDate bookingDate) {
        // implementation here
        this.customer=customer;
        this.flight=flight;
        this.bookingDate=bookingDate;
        this.id=counter++;
    }
    
    // implementation of Getter and Setter methods
    public Customer getCustomer(){
        return this.customer;
    }
    public Flight getFlight(){
        return this.flight;
    }
    public LocalDate getBookingDate(){
        return this.bookingDate;
    }
    public void setCustomer(Customer customer){
        this.customer=customer;
    }
    public void setFlight(Flight flight){
        this.flight=flight;
    }
    public void setBookingDate(LocalDate bookingDate){
        this.bookingDate=bookingDate;
    }
    public int getId(){
        return this.id;
    }
    
}