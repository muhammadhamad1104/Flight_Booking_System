package bcu.cmp5332.bookingsystem.commands;

import bcu.cmp5332.bookingsystem.main.FlightBookingSystemException;
import bcu.cmp5332.bookingsystem.model.Flight;
import bcu.cmp5332.bookingsystem.model.FlightBookingSystem;
import java.time.LocalDate;

public class AddFlight implements  Command {

    private final String flightNumber;
    private final String origin;
    private final String destination;
    private final LocalDate departureDate;
    private final int capacity;
    private final double price;
    private Flight flight;
    private boolean flightAdded = false;
    public AddFlight(String flightNumber, String origin, String destination, LocalDate departureDate,int capacity,double price) {
        this.flightNumber = flightNumber;
        this.origin = origin;
        this.destination = destination;
        this.departureDate = departureDate;
        this.capacity=capacity;
        this.price=price;
    }
    
    @Override
    public void execute(FlightBookingSystem flightBookingSystem) throws FlightBookingSystemException {
        int maxId = 0;
        if (!flightBookingSystem.getFlights().isEmpty()) {
            int lastIndex = flightBookingSystem.getFlights().size() - 1;
            maxId = flightBookingSystem.getFlights().get(lastIndex).getId();
        }
        
        flight = new Flight(++maxId, flightNumber, origin, destination, departureDate,capacity,price);
        flightBookingSystem.addFlight(flight);
        flightAdded = true;
        System.out.println("Flight #" + flight.getId() + " added.");
    }

    //@Override
    public void rollBack(FlightBookingSystem flightBookingSystem) throws FlightBookingSystemException {
        if(flightAdded){
            flightBookingSystem.removeFlight(flight);
            System.out.println("Flight #" + flight.getId() + " removed.");
        }else{
            throw new FlightBookingSystemException("No flight found to remove");
        }
    }
}
