package bcu.cmp5332.bookingsystem.commands;

import bcu.cmp5332.bookingsystem.main.FlightBookingSystemException;
import bcu.cmp5332.bookingsystem.model.Booking;
import bcu.cmp5332.bookingsystem.model.Customer;
import bcu.cmp5332.bookingsystem.model.Flight;
import bcu.cmp5332.bookingsystem.model.FlightBookingSystem;

public class CancelBooking implements Command {
    public final int customerID;
    public final int flightID;
    private Booking CancelBooking;
    public CancelBooking(int customerID,int flightID){
        this.customerID=customerID;
        this.flightID=flightID;
    }
    @Override
    public void execute(FlightBookingSystem flightBookingSystem) throws FlightBookingSystemException {
        Customer customer=flightBookingSystem.getCustomerByID(customerID);
        Flight flight=flightBookingSystem.getFlightByID(flightID);
        CancelBooking=customer.getBookingByFlight(flight);
        if(CancelBooking==null){
            throw new FlightBookingSystemException("The customer does not have a booking for this flight");
        }
        customer.cancelBookingForFlight(flight);
        flight.removePassenger(customer);
        System.out.println("Booking cancelled for Customer #"+customerID+" on flight #"+flightID);
    }
    public void rollBack(FlightBookingSystem flightBookingSystem) throws FlightBookingSystemException {
        if(CancelBooking==null){
            throw new FlightBookingSystemException("The customer does not have a booking for this flight");
        }
        Customer customer=flightBookingSystem.getCustomerByID(customerID);
        Flight flight=flightBookingSystem.getFlightByID(flightID);
        customer.addBooking(CancelBooking);
        flight.addPassenger(customer);
        System.out.println("Booking added for Customer #"+customerID+" on flight #"+flightID);
    }
}
