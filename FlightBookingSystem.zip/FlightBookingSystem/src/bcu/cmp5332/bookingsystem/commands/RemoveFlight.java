// package bcu.cmp5332.bookingsystem.commands;

// import bcu.cmp5332.bookingsystem.main.FlightBookingSystemException;
// import bcu.cmp5332.bookingsystem.model.Flight;
// import bcu.cmp5332.bookingsystem.model.FlightBookingSystem;

// public class RemoveFlight implements Command {
//     private final int id;
//     private Flight removedFlight;
//     public RemoveFlight(int id) {
//         this.id = id;
//     }
//     @Override
//     public void execute(FlightBookingSystem flightBookingSystem) throws FlightBookingSystemException {
//         removedFlight=flightBookingSystem.getFlightByID(id);
//         if(removedFlight==null){
//             throw new FlightBookingSystemException("No flight found with ID "+id);
//         }
//         flightBookingSystem.removeFlight(removedFlight);
//         System.out.println("Flight #"+id+" removed.");
//     }
//     public void rollBack(FlightBookingSystem flightBookingSystem) throws FlightBookingSystemException {
//         if(removedFlight!=null){
//             flightBookingSystem.addFlight(removedFlight);
//             System.out.println("Flight #"+id+" restored.");
//         }else{
//             throw new FlightBookingSystemException("No flight found to remove");
//         }
//     }
    
// }