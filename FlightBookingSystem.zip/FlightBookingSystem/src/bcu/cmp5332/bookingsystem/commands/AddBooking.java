package bcu.cmp5332.bookingsystem.commands;

import bcu.cmp5332.bookingsystem.main.FlightBookingSystemException;
import bcu.cmp5332.bookingsystem.model.Booking;
import bcu.cmp5332.bookingsystem.model.Customer;
import bcu.cmp5332.bookingsystem.model.Flight;
import bcu.cmp5332.bookingsystem.model.FlightBookingSystem;
import java.time.LocalDate;

public class AddBooking implements Command {
    public final int customerID;
    public final int flightID;
    public final LocalDate BookingDate;
    public AddBooking(int customerID,int flightID,LocalDate BookingDate){
        this.customerID=customerID;
        this.flightID=flightID;
        this.BookingDate=BookingDate;
    }
    @Override
    public void execute(FlightBookingSystem flightBookingSystem) throws FlightBookingSystemException {
        Customer customer=flightBookingSystem.getCustomerByID(customerID);
        Flight flight=flightBookingSystem.getFlightByID(flightID);
        Booking booking=new Booking(customer, flight, BookingDate);
        if(flight.isFull()){
            throw new FlightBookingSystemException("The flight is full");
        }
        customer.addBooking(booking);
        flight.addPassenger(customer);
        System.out.println("Booking added for Customer #"+customerID+" on flight #"+flightID);
    }
    
}
