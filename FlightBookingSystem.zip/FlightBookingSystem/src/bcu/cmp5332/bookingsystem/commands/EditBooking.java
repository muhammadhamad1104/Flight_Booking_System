package bcu.cmp5332.bookingsystem.commands;

import bcu.cmp5332.bookingsystem.main.FlightBookingSystemException;
import bcu.cmp5332.bookingsystem.model.Booking;
import bcu.cmp5332.bookingsystem.model.Customer;
import bcu.cmp5332.bookingsystem.model.Flight;
import bcu.cmp5332.bookingsystem.model.FlightBookingSystem;

public class EditBooking implements Command {
    private final int customerID;
    private final int newFlightID;
    public EditBooking(int customerID,int newFlightID){
        this.customerID=customerID;
        this.newFlightID=newFlightID;
    }

    @Override
    public void execute(FlightBookingSystem flightBookingSystem) throws FlightBookingSystemException {
        Customer customer = flightBookingSystem.getCustomerByID(customerID);
        Booking existingBooking=null;
        for(Booking booking:customer.getBookings()){
            if(booking.getFlight().getId()==newFlightID){
                throw new FlightBookingSystemException("The customer already has a booking for this flight");
            }
            existingBooking=booking;
        }
        if(existingBooking==null){
            throw new FlightBookingSystemException("The customer does not have a booking for this flight");
        }
        Flight newFlight=flightBookingSystem.getFlightByID(newFlightID);
        // if(newFlight.getPassengers().size()>=newFlight.getCapacity()){
        //     throw new FlightBookingSystemException("The flight is full");
        // }
        Flight oldFlight=existingBooking.getFlight();
        oldFlight.removePassenger(customer);
        newFlight.addPassenger(customer);
        existingBooking.setFlight(newFlight);
        System.out.println("Booking updated for customer #"+customerID+" to flight #"+newFlightID);
    }
}
